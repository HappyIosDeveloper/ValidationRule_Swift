//
//  ViewController.swift
//  ValidatorDemo
//
//  Created by Ahmadreza on 6/23/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        validation()
    }

    func validation() {
        let limitedText = "Hello"
        let phone = "09122222222"
        let phone2 = "122222222333"
        let email = "BlahBlah@gmail.com"

        let textValidation = ValidationRule.text(.limited(text: limitedText, min: 2, max: 10)).validate()
        let isPhone1Valid = ValidationRule.phone(.mobile(phone)).validate().isValid
        let phone2ValidationError = ValidationRule.phone(.mobile(phone2)).validate().error
        let emailValidation = ValidationRule.email(.completed(email: email))
        
        print("textValidation", textValidation.isValid)
        print("isPhone1Valid", isPhone1Valid)
        print("phone2ValidationError", phone2ValidationError!)
        print("emailValidation", emailValidation.validate().isValid)
        
        // Of course your can write it like this
        let newPhoneValidation = PhoneValidator(type: .mobile(phone)).validate().isValid
        print("newPhoneValidation", newPhoneValidation)
    }
}



import Foundation

class PasswordValidator {
    
    enum ValidationType {
        case completed(pass: String)
        case incomplete(pass: String, char: String)
    }
    
    enum PasswordType { case otp(ValidationType), general(ValidationType) }
    
    private var type: PasswordType
    private let validationRegex = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$"
    private let maximumGeneralCharactersCount = 20
    private let maximumOtpCharactersCount = 6

    init(type: PasswordType) {
        self.type = type
    }
}

// MARK: - Functions
extension PasswordValidator {
    
    func validate()-> ValidationRule.Result {
        switch type {
        case .general(let completion):
            switch completion {
            case .completed(let pass):
                return isValidGeneralPassword(pass: pass)
            case .incomplete(let pass, let char):
                return isValidInCompleteGeneralPassword(pass: pass, char: char)
            }
        case .otp(let completion):
            switch completion {
            case .completed(let pass):
                return isValidOtpPassword(pass: pass)
            case .incomplete(let pass, let char):
                return isValidInCompleteOtpPassword(pass: pass, char: char)
            }
        }
    }
    
    func isValid(text: String, newChar: String)-> Bool {
        switch type {
        case .general(let completion):
            switch completion {
            case .completed:
                return PasswordValidator(type: .general(.completed(pass: text))).validate().isValid
            case .incomplete:
                return PasswordValidator(type: .general(.incomplete(pass: text, char: newChar))).validate().isValid
            }
        case .otp(let completion):
            switch completion {
            case .completed:
                return PasswordValidator(type: .otp(.completed(pass: text))).validate().isValid
            case .incomplete:
                return PasswordValidator(type: .otp(.incomplete(pass: text, char: newChar))).validate().isValid
            }
        }
    }
}

// MARK: - General
extension PasswordValidator {
    
    private func isValidGeneralPassword(pass: String)-> ValidationRule.Result {
        let isValid = (NSPredicate(format: "SELF MATCHES %@", validationRegex).evaluate(with: pass))
        if isValid && pass.count <= maximumGeneralCharactersCount {
            return ValidationRule.Result(error: nil)
        } else {
            return ValidationRule.Result(error: "wrong_password")
        }
    }
    
    private func isValidInCompleteGeneralPassword(pass: String, char: String)-> ValidationRule.Result {
        if pass.isEmpty { return ValidationRule.Result(error: nil) }
        if pass.count <= maximumGeneralCharactersCount {
            return ValidationRule.Result(error: nil)
        } else {
            return ValidationRule.Result(error: "wrong_password")
        }
    }
}

// MARK: - OTP
extension PasswordValidator {
    
    private func isValidOtpPassword(pass: String)-> ValidationRule.Result {
        let isValid = (NSPredicate(format: "SELF MATCHES %@", validationRegex).evaluate(with: pass))
        if isValid && pass.count <= maximumOtpCharactersCount {
            return ValidationRule.Result(error: nil)
        } else {
            return ValidationRule.Result(error: "wrong_code")
        }
    }
    
    private func isValidInCompleteOtpPassword(pass: String, char: String)-> ValidationRule.Result {
        if pass.isEmpty { return ValidationRule.Result(error: nil) }
        if pass.count <= maximumOtpCharactersCount {
            return ValidationRule.Result(error: nil)
        } else {
            return ValidationRule.Result(error: "wrong_code")
        }
    }
}

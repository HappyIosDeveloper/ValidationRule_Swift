
import Foundation

class TextValidator {
    
    enum TextType {
        case nationalID(ID: String)
        case limited(text: String, min: Int, max: Int)
        case price(text: String, min: Int, max: Int, step: Int?)
    }
    
    private var type: TextType
    
    init(type: TextType) {
        self.type = type
    }
}

// MARK: - Functions
extension TextValidator {
    
    func validate() -> ValidationRule.Result {
        switch type {
        case .nationalID(let ID):
            return isValidNationalID(ID)
        case .limited(let text, let min, let max):
            return isLimitedTextValid(text: text, min: min, max: max)
        case .price(let text, let min, let max, let step):
            return isValidPrice(text: text, min: min, max: max, step: step)
        }
    }
    
    private func isValidNationalID(_ id: String)-> ValidationRule.Result {
        // calculation here
        return ValidationRule.Result(error: nil)
    }
    
    private func isLimitedTextValid(text: String, min: Int, max: Int)-> ValidationRule.Result {
        // calculation here
        return ValidationRule.Result(error: nil)
    }
    
    private func isValidPrice(text: String, min: Int, max: Int, step: Int?)-> ValidationRule.Result {
        // calculation here
        return ValidationRule.Result(error: nil)
    }
}


import Foundation

class EmailValidator {
    
    enum ValidationType {
        case completed(email: String)
        case incomplete(email: String, char: String)
    }
    
    private var type: ValidationType
    
    init(type: ValidationType) {
        self.type = type
    }
}

// MARK: - Functions
extension EmailValidator {
    
    func validate()-> ValidationRule.Result {
        switch type {
        case .completed(let email):
            return isValidEmail(text: email)
        case .incomplete(let email, let char):
            return isValidIncompleteEmail(character: char, text: email)
        }
    }
    
    private func isValidEmail(text: String)-> ValidationRule.Result {
        let isValid = (NSPredicate(format: "SELF MATCHES %@", "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}").evaluate(with: text))
        if isValid {
            return ValidationRule.Result(error: nil)
        } else {
            return ValidationRule.Result(error: "wrong_email")
        }
    }
    
    private func isValidIncompleteEmail(character: String?, text: String)-> ValidationRule.Result {
        if text.count > 40 { return ValidationRule.Result(error: nil) }
        guard let character = character else { return ValidationRule.Result(error: "error") }
        if character.isEmpty { return ValidationRule.Result(error: nil) }
        let regex = "[a-zA-Z0-9@_.]+"
        let email = NSPredicate(format: "SELF MATCHES %@", regex)
        let isValid = email.evaluate(with: character)
        if isValid {
            return ValidationRule.Result(error: nil)
        } else {
            return ValidationRule.Result(error: "wrong_email")
        }
    }
}

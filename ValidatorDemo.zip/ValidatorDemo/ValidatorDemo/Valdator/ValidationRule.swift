
import Foundation

enum ValidationRule {
    
    struct Result {
        var error: String?
        var isValid: Bool {
            return error == nil
        }
    }

    case text(TextValidator.TextType)
    case phone(PhoneValidator.PhoneType)
    case email(EmailValidator.ValidationType)
    case password(PasswordValidator.PasswordType)
    
    func validate()-> Result {
        switch self {
        case .phone(let phoneType):
            return PhoneValidator(type: phoneType).validate()
        case .text(let textType):
            return TextValidator(type: textType).validate()
        case .email(let emailType):
            return EmailValidator(type: emailType).validate()
        case .password(let type):
            return PasswordValidator(type: type).validate()
        }
    }
}

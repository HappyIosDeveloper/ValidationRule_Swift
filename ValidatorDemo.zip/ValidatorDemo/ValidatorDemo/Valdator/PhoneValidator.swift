
import Foundation

class PhoneValidator {
    
    enum PhoneType {
        case mobile(String)
        case incompleteMobile(String)
    }
    
    private var type: PhoneType
    
    init(type: PhoneType) {
        self.type = type
    }
}

// MARK: - Functions
extension PhoneValidator {
    
    func validate()-> ValidationRule.Result {
        switch type {
        case .mobile(let number):
            return isValidMobileNumber(phone: number)
        case .incompleteMobile(let number):
            return isValidIncompleteMobileNumber(phone: number)
        }
    }
    
    private func isValidMobileNumber(phone: String)-> ValidationRule.Result {
        if phone.isEmpty {
            return ValidationRule.Result(error: "wrong_phone_number")
        }
        if phone.count == (phone.first! == "0" ? 11 : 10) && (phone.first! == "9" || phone.prefix(2) == "09") {
            return ValidationRule.Result(error: nil)
        }
        return ValidationRule.Result(error: "wrong_phone_number")
    }
    
    private func isValidIncompleteMobileNumber(phone: String)-> ValidationRule.Result {
        if phone.isEmpty {
            return ValidationRule.Result(error: nil)
        } else if ((phone.prefix(2) == "09" && phone.count < 12) || (phone.first! == "9" && phone.count < 11) || (phone.first! == "0" && phone.count == 1)) {
            return ValidationRule.Result(error: nil)
        } else {
            return ValidationRule.Result(error: "wrong_phone_number")
        }
    }
}
